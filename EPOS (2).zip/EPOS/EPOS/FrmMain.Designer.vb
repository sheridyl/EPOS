﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmMain))
        Me.btnWhiskey = New System.Windows.Forms.Button()
        Me.btnWine = New System.Windows.Forms.Button()
        Me.btnStout = New System.Windows.Forms.Button()
        Me.btnCider = New System.Windows.Forms.Button()
        Me.btnAle = New System.Windows.Forms.Button()
        Me.btnLager = New System.Windows.Forms.Button()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.btnConfirm = New System.Windows.Forms.Button()
        Me.btnSignOut = New System.Windows.Forms.Button()
        Me.btnSoftDrinks = New System.Windows.Forms.Button()
        Me.btnSpirits = New System.Windows.Forms.Button()
        Me.btnCocktails = New System.Windows.Forms.Button()
        Me.btnTeaCoffee = New System.Windows.Forms.Button()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.PictureBox11 = New System.Windows.Forms.PictureBox()
        Me.btnDinner = New System.Windows.Forms.Button()
        Me.btnSoup = New System.Windows.Forms.Button()
        Me.btnLunch = New System.Windows.Forms.Button()
        Me.btnSandwiches = New System.Windows.Forms.Button()
        Me.btnManagerControls = New System.Windows.Forms.Button()
        Me.btnPubSpecials = New System.Windows.Forms.Button()
        Me.btnCrisps = New System.Windows.Forms.Button()
        Me.btnChocolate = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.Button32 = New System.Windows.Forms.Button()
        Me.Button34 = New System.Windows.Forms.Button()
        Me.Button35 = New System.Windows.Forms.Button()
        Me.Button36 = New System.Windows.Forms.Button()
        Me.Button37 = New System.Windows.Forms.Button()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnWhiskey
        '
        Me.btnWhiskey.BackColor = System.Drawing.Color.Goldenrod
        Me.btnWhiskey.BackgroundImage = CType(resources.GetObject("btnWhiskey.BackgroundImage"), System.Drawing.Image)
        Me.btnWhiskey.Font = New System.Drawing.Font("Mistral", 52.25!)
        Me.btnWhiskey.Location = New System.Drawing.Point(7, 82)
        Me.btnWhiskey.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnWhiskey.Name = "btnWhiskey"
        Me.btnWhiskey.Size = New System.Drawing.Size(307, 236)
        Me.btnWhiskey.TabIndex = 0
        Me.btnWhiskey.Text = "Whiskey"
        Me.btnWhiskey.UseVisualStyleBackColor = False
        '
        'btnWine
        '
        Me.btnWine.BackColor = System.Drawing.Color.Firebrick
        Me.btnWine.Font = New System.Drawing.Font("Mistral", 54.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnWine.Location = New System.Drawing.Point(7, 326)
        Me.btnWine.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnWine.Name = "btnWine"
        Me.btnWine.Size = New System.Drawing.Size(307, 236)
        Me.btnWine.TabIndex = 1
        Me.btnWine.Text = "Wine"
        Me.btnWine.UseVisualStyleBackColor = False
        '
        'btnStout
        '
        Me.btnStout.BackColor = System.Drawing.Color.BurlyWood
        Me.btnStout.Font = New System.Drawing.Font("Mistral", 54.25!)
        Me.btnStout.ForeColor = System.Drawing.Color.Black
        Me.btnStout.Location = New System.Drawing.Point(321, 82)
        Me.btnStout.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnStout.Name = "btnStout"
        Me.btnStout.Size = New System.Drawing.Size(304, 236)
        Me.btnStout.TabIndex = 2
        Me.btnStout.Text = "Stout"
        Me.btnStout.UseVisualStyleBackColor = False
        '
        'btnCider
        '
        Me.btnCider.BackColor = System.Drawing.Color.DarkOrange
        Me.btnCider.Font = New System.Drawing.Font("Mistral", 54.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCider.Location = New System.Drawing.Point(321, 326)
        Me.btnCider.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnCider.Name = "btnCider"
        Me.btnCider.Size = New System.Drawing.Size(304, 236)
        Me.btnCider.TabIndex = 3
        Me.btnCider.Text = "Cider"
        Me.btnCider.UseVisualStyleBackColor = False
        '
        'btnAle
        '
        Me.btnAle.BackColor = System.Drawing.Color.Gold
        Me.btnAle.Font = New System.Drawing.Font("Mistral", 54.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAle.Location = New System.Drawing.Point(633, 82)
        Me.btnAle.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnAle.Name = "btnAle"
        Me.btnAle.Size = New System.Drawing.Size(304, 236)
        Me.btnAle.TabIndex = 4
        Me.btnAle.Text = "Ale"
        Me.btnAle.UseVisualStyleBackColor = False
        '
        'btnLager
        '
        Me.btnLager.BackColor = System.Drawing.Color.Khaki
        Me.btnLager.Font = New System.Drawing.Font("Mistral", 54.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLager.Location = New System.Drawing.Point(633, 326)
        Me.btnLager.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnLager.Name = "btnLager"
        Me.btnLager.Size = New System.Drawing.Size(304, 236)
        Me.btnLager.TabIndex = 5
        Me.btnLager.Text = "Lager"
        Me.btnLager.UseVisualStyleBackColor = False
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 16
        Me.ListBox1.Location = New System.Drawing.Point(1085, 82)
        Me.ListBox1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(343, 484)
        Me.ListBox1.TabIndex = 6
        '
        'Button7
        '
        Me.Button7.Font = New System.Drawing.Font("Mistral", 22.75!)
        Me.Button7.Location = New System.Drawing.Point(1120, 589)
        Me.Button7.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(69, 57)
        Me.Button7.TabIndex = 7
        Me.Button7.Text = "1"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Font = New System.Drawing.Font("Mistral", 22.75!)
        Me.Button8.Location = New System.Drawing.Point(1218, 589)
        Me.Button8.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(71, 57)
        Me.Button8.TabIndex = 8
        Me.Button8.Text = "2"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Font = New System.Drawing.Font("Mistral", 22.75!)
        Me.Button9.Location = New System.Drawing.Point(1312, 589)
        Me.Button9.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(72, 57)
        Me.Button9.TabIndex = 9
        Me.Button9.Text = "3"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Font = New System.Drawing.Font("Mistral", 22.75!)
        Me.Button10.Location = New System.Drawing.Point(1312, 654)
        Me.Button10.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(72, 57)
        Me.Button10.TabIndex = 12
        Me.Button10.Text = "6"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Font = New System.Drawing.Font("Mistral", 22.75!)
        Me.Button11.Location = New System.Drawing.Point(1218, 654)
        Me.Button11.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(71, 57)
        Me.Button11.TabIndex = 11
        Me.Button11.Text = "5"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.Font = New System.Drawing.Font("Mistral", 22.75!)
        Me.Button12.Location = New System.Drawing.Point(1120, 654)
        Me.Button12.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(69, 57)
        Me.Button12.TabIndex = 10
        Me.Button12.Text = "4"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.Font = New System.Drawing.Font("Mistral", 22.75!)
        Me.Button13.Location = New System.Drawing.Point(1312, 719)
        Me.Button13.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(72, 57)
        Me.Button13.TabIndex = 15
        Me.Button13.Text = "9"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.Font = New System.Drawing.Font("Mistral", 22.75!)
        Me.Button14.Location = New System.Drawing.Point(1218, 719)
        Me.Button14.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(71, 57)
        Me.Button14.TabIndex = 14
        Me.Button14.Text = "8"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Button15
        '
        Me.Button15.Font = New System.Drawing.Font("Mistral", 22.75!)
        Me.Button15.Location = New System.Drawing.Point(1120, 719)
        Me.Button15.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(69, 55)
        Me.Button15.TabIndex = 13
        Me.Button15.Text = "7"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'btnConfirm
        '
        Me.btnConfirm.BackColor = System.Drawing.Color.LimeGreen
        Me.btnConfirm.Font = New System.Drawing.Font("Mistral", 13.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnConfirm.Location = New System.Drawing.Point(1428, 589)
        Me.btnConfirm.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnConfirm.Name = "btnConfirm"
        Me.btnConfirm.Size = New System.Drawing.Size(99, 185)
        Me.btnConfirm.TabIndex = 16
        Me.btnConfirm.Text = "Confirm"
        Me.btnConfirm.UseVisualStyleBackColor = False
        '
        'btnSignOut
        '
        Me.btnSignOut.BackColor = System.Drawing.Color.LavenderBlush
        Me.btnSignOut.Font = New System.Drawing.Font("Mistral", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSignOut.Location = New System.Drawing.Point(1328, 783)
        Me.btnSignOut.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnSignOut.Name = "btnSignOut"
        Me.btnSignOut.Size = New System.Drawing.Size(169, 47)
        Me.btnSignOut.TabIndex = 17
        Me.btnSignOut.Text = "Sign Out"
        Me.btnSignOut.UseVisualStyleBackColor = False
        '
        'btnSoftDrinks
        '
        Me.btnSoftDrinks.BackColor = System.Drawing.Color.Teal
        Me.btnSoftDrinks.Font = New System.Drawing.Font("Mistral", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSoftDrinks.Location = New System.Drawing.Point(7, 570)
        Me.btnSoftDrinks.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnSoftDrinks.Name = "btnSoftDrinks"
        Me.btnSoftDrinks.Size = New System.Drawing.Size(149, 124)
        Me.btnSoftDrinks.TabIndex = 19
        Me.btnSoftDrinks.Text = "Soft Drinks"
        Me.btnSoftDrinks.UseVisualStyleBackColor = False
        '
        'btnSpirits
        '
        Me.btnSpirits.BackColor = System.Drawing.Color.RoyalBlue
        Me.btnSpirits.Font = New System.Drawing.Font("Mistral", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSpirits.Location = New System.Drawing.Point(7, 702)
        Me.btnSpirits.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnSpirits.Name = "btnSpirits"
        Me.btnSpirits.Size = New System.Drawing.Size(149, 127)
        Me.btnSpirits.TabIndex = 20
        Me.btnSpirits.Text = "Spirits"
        Me.btnSpirits.UseVisualStyleBackColor = False
        '
        'btnCocktails
        '
        Me.btnCocktails.BackColor = System.Drawing.Color.LightCyan
        Me.btnCocktails.Font = New System.Drawing.Font("Mistral", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCocktails.Location = New System.Drawing.Point(164, 570)
        Me.btnCocktails.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnCocktails.Name = "btnCocktails"
        Me.btnCocktails.Size = New System.Drawing.Size(149, 126)
        Me.btnCocktails.TabIndex = 21
        Me.btnCocktails.Text = "Cocktails"
        Me.btnCocktails.UseVisualStyleBackColor = False
        '
        'btnTeaCoffee
        '
        Me.btnTeaCoffee.BackColor = System.Drawing.Color.MediumBlue
        Me.btnTeaCoffee.Font = New System.Drawing.Font("Mistral", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTeaCoffee.Location = New System.Drawing.Point(164, 703)
        Me.btnTeaCoffee.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnTeaCoffee.Name = "btnTeaCoffee"
        Me.btnTeaCoffee.Size = New System.Drawing.Size(149, 127)
        Me.btnTeaCoffee.TabIndex = 22
        Me.btnTeaCoffee.Text = "Tea/Coffee"
        Me.btnTeaCoffee.UseVisualStyleBackColor = False
        '
        'PictureBox5
        '
        Me.PictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox5.Image = CType(resources.GetObject("PictureBox5.Image"), System.Drawing.Image)
        Me.PictureBox5.Location = New System.Drawing.Point(560, 0)
        Me.PictureBox5.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(156, 75)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox5.TabIndex = 27
        Me.PictureBox5.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), System.Drawing.Image)
        Me.PictureBox4.Location = New System.Drawing.Point(425, 0)
        Me.PictureBox4.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(156, 75)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 26
        Me.PictureBox4.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(129, 0)
        Me.PictureBox2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(156, 75)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 25
        Me.PictureBox2.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(281, 0)
        Me.PictureBox3.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(156, 75)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 24
        Me.PictureBox3.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, -10)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(156, 85)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 23
        Me.PictureBox1.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox6.Image = CType(resources.GetObject("PictureBox6.Image"), System.Drawing.Image)
        Me.PictureBox6.Location = New System.Drawing.Point(999, 0)
        Me.PictureBox6.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(156, 75)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox6.TabIndex = 30
        Me.PictureBox6.TabStop = False
        '
        'PictureBox7
        '
        Me.PictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox7.Image = CType(resources.GetObject("PictureBox7.Image"), System.Drawing.Image)
        Me.PictureBox7.Location = New System.Drawing.Point(848, 0)
        Me.PictureBox7.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(156, 75)
        Me.PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox7.TabIndex = 29
        Me.PictureBox7.TabStop = False
        '
        'PictureBox8
        '
        Me.PictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox8.Image = CType(resources.GetObject("PictureBox8.Image"), System.Drawing.Image)
        Me.PictureBox8.Location = New System.Drawing.Point(700, 0)
        Me.PictureBox8.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(156, 75)
        Me.PictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox8.TabIndex = 28
        Me.PictureBox8.TabStop = False
        '
        'PictureBox9
        '
        Me.PictureBox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox9.Image = CType(resources.GetObject("PictureBox9.Image"), System.Drawing.Image)
        Me.PictureBox9.Location = New System.Drawing.Point(1312, 0)
        Me.PictureBox9.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(257, 75)
        Me.PictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox9.TabIndex = 33
        Me.PictureBox9.TabStop = False
        '
        'PictureBox10
        '
        Me.PictureBox10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox10.Image = CType(resources.GetObject("PictureBox10.Image"), System.Drawing.Image)
        Me.PictureBox10.Location = New System.Drawing.Point(1177, 0)
        Me.PictureBox10.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(156, 75)
        Me.PictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox10.TabIndex = 32
        Me.PictureBox10.TabStop = False
        '
        'PictureBox11
        '
        Me.PictureBox11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox11.Image = CType(resources.GetObject("PictureBox11.Image"), System.Drawing.Image)
        Me.PictureBox11.Location = New System.Drawing.Point(1033, 0)
        Me.PictureBox11.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.PictureBox11.Name = "PictureBox11"
        Me.PictureBox11.Size = New System.Drawing.Size(156, 75)
        Me.PictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox11.TabIndex = 31
        Me.PictureBox11.TabStop = False
        '
        'btnDinner
        '
        Me.btnDinner.BackColor = System.Drawing.Color.CornflowerBlue
        Me.btnDinner.Font = New System.Drawing.Font("Mistral", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDinner.Location = New System.Drawing.Point(479, 703)
        Me.btnDinner.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnDinner.Name = "btnDinner"
        Me.btnDinner.Size = New System.Drawing.Size(149, 127)
        Me.btnDinner.TabIndex = 37
        Me.btnDinner.Text = "Dinner"
        Me.btnDinner.UseVisualStyleBackColor = False
        '
        'btnSoup
        '
        Me.btnSoup.BackColor = System.Drawing.Color.CadetBlue
        Me.btnSoup.Font = New System.Drawing.Font("Mistral", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSoup.Location = New System.Drawing.Point(479, 570)
        Me.btnSoup.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnSoup.Name = "btnSoup"
        Me.btnSoup.Size = New System.Drawing.Size(149, 126)
        Me.btnSoup.TabIndex = 36
        Me.btnSoup.Text = "Soup"
        Me.btnSoup.UseVisualStyleBackColor = False
        '
        'btnLunch
        '
        Me.btnLunch.BackColor = System.Drawing.Color.SkyBlue
        Me.btnLunch.Font = New System.Drawing.Font("Mistral", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLunch.Location = New System.Drawing.Point(321, 703)
        Me.btnLunch.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnLunch.Name = "btnLunch"
        Me.btnLunch.Size = New System.Drawing.Size(149, 127)
        Me.btnLunch.TabIndex = 35
        Me.btnLunch.Text = "Lunch"
        Me.btnLunch.UseVisualStyleBackColor = False
        '
        'btnSandwiches
        '
        Me.btnSandwiches.BackColor = System.Drawing.Color.Aquamarine
        Me.btnSandwiches.Font = New System.Drawing.Font("Mistral", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSandwiches.Location = New System.Drawing.Point(321, 570)
        Me.btnSandwiches.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnSandwiches.Name = "btnSandwiches"
        Me.btnSandwiches.Size = New System.Drawing.Size(149, 124)
        Me.btnSandwiches.TabIndex = 34
        Me.btnSandwiches.Text = "Sandwiches"
        Me.btnSandwiches.UseVisualStyleBackColor = False
        '
        'btnManagerControls
        '
        Me.btnManagerControls.BackColor = System.Drawing.Color.LightBlue
        Me.btnManagerControls.Font = New System.Drawing.Font("Mistral", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnManagerControls.Location = New System.Drawing.Point(791, 703)
        Me.btnManagerControls.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnManagerControls.Name = "btnManagerControls"
        Me.btnManagerControls.Size = New System.Drawing.Size(149, 127)
        Me.btnManagerControls.TabIndex = 41
        Me.btnManagerControls.Text = "Manager Controls"
        Me.btnManagerControls.UseVisualStyleBackColor = False
        '
        'btnPubSpecials
        '
        Me.btnPubSpecials.BackColor = System.Drawing.Color.Silver
        Me.btnPubSpecials.Font = New System.Drawing.Font("Mistral", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPubSpecials.Location = New System.Drawing.Point(791, 570)
        Me.btnPubSpecials.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnPubSpecials.Name = "btnPubSpecials"
        Me.btnPubSpecials.Size = New System.Drawing.Size(149, 126)
        Me.btnPubSpecials.TabIndex = 40
        Me.btnPubSpecials.Text = "Pub Specials"
        Me.btnPubSpecials.UseVisualStyleBackColor = False
        '
        'btnCrisps
        '
        Me.btnCrisps.BackColor = System.Drawing.Color.DarkTurquoise
        Me.btnCrisps.Font = New System.Drawing.Font("Mistral", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCrisps.Location = New System.Drawing.Point(633, 703)
        Me.btnCrisps.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnCrisps.Name = "btnCrisps"
        Me.btnCrisps.Size = New System.Drawing.Size(149, 127)
        Me.btnCrisps.TabIndex = 39
        Me.btnCrisps.Text = "Crisps"
        Me.btnCrisps.UseVisualStyleBackColor = False
        '
        'btnChocolate
        '
        Me.btnChocolate.BackColor = System.Drawing.Color.SteelBlue
        Me.btnChocolate.Font = New System.Drawing.Font("Mistral", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnChocolate.Location = New System.Drawing.Point(633, 570)
        Me.btnChocolate.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnChocolate.Name = "btnChocolate"
        Me.btnChocolate.Size = New System.Drawing.Size(149, 124)
        Me.btnChocolate.TabIndex = 38
        Me.btnChocolate.Text = "Chocolate"
        Me.btnChocolate.UseVisualStyleBackColor = False
        '
        'btnDelete
        '
        Me.btnDelete.BackColor = System.Drawing.Color.Red
        Me.btnDelete.Font = New System.Drawing.Font("Mistral", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDelete.Location = New System.Drawing.Point(976, 589)
        Me.btnDelete.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(115, 185)
        Me.btnDelete.TabIndex = 42
        Me.btnDelete.Text = "Delete"
        Me.btnDelete.UseVisualStyleBackColor = False
        '
        'Button32
        '
        Me.Button32.Font = New System.Drawing.Font("Mistral", 22.75!)
        Me.Button32.Location = New System.Drawing.Point(1218, 784)
        Me.Button32.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button32.Name = "Button32"
        Me.Button32.Size = New System.Drawing.Size(71, 47)
        Me.Button32.TabIndex = 43
        Me.Button32.Text = "0"
        Me.Button32.UseVisualStyleBackColor = True
        '
        'Button34
        '
        Me.Button34.BackColor = System.Drawing.Color.YellowGreen
        Me.Button34.Font = New System.Drawing.Font("Mistral", 32.0!)
        Me.Button34.Location = New System.Drawing.Point(1436, 98)
        Me.Button34.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button34.Name = "Button34"
        Me.Button34.Size = New System.Drawing.Size(91, 106)
        Me.Button34.TabIndex = 45
        Me.Button34.Text = "€5"
        Me.Button34.UseVisualStyleBackColor = False
        '
        'Button35
        '
        Me.Button35.BackColor = System.Drawing.Color.OliveDrab
        Me.Button35.Font = New System.Drawing.Font("Mistral", 24.0!)
        Me.Button35.Location = New System.Drawing.Point(1436, 212)
        Me.Button35.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button35.Name = "Button35"
        Me.Button35.Size = New System.Drawing.Size(91, 106)
        Me.Button35.TabIndex = 46
        Me.Button35.Text = "€10"
        Me.Button35.UseVisualStyleBackColor = False
        '
        'Button36
        '
        Me.Button36.BackColor = System.Drawing.Color.Green
        Me.Button36.Font = New System.Drawing.Font("Mistral", 24.0!)
        Me.Button36.Location = New System.Drawing.Point(1436, 326)
        Me.Button36.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button36.Name = "Button36"
        Me.Button36.Size = New System.Drawing.Size(91, 106)
        Me.Button36.TabIndex = 47
        Me.Button36.Text = "€20"
        Me.Button36.UseVisualStyleBackColor = False
        '
        'Button37
        '
        Me.Button37.BackColor = System.Drawing.Color.DarkGreen
        Me.Button37.Font = New System.Drawing.Font("Mistral", 24.0!)
        Me.Button37.Location = New System.Drawing.Point(1436, 440)
        Me.Button37.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button37.Name = "Button37"
        Me.Button37.Size = New System.Drawing.Size(91, 106)
        Me.Button37.TabIndex = 48
        Me.Button37.Text = "€50"
        Me.Button37.UseVisualStyleBackColor = False
        '
        'FrmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1582, 853)
        Me.Controls.Add(Me.Button37)
        Me.Controls.Add(Me.Button36)
        Me.Controls.Add(Me.Button35)
        Me.Controls.Add(Me.Button34)
        Me.Controls.Add(Me.Button32)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnManagerControls)
        Me.Controls.Add(Me.btnPubSpecials)
        Me.Controls.Add(Me.btnCrisps)
        Me.Controls.Add(Me.btnChocolate)
        Me.Controls.Add(Me.btnDinner)
        Me.Controls.Add(Me.btnSoup)
        Me.Controls.Add(Me.btnLunch)
        Me.Controls.Add(Me.btnSandwiches)
        Me.Controls.Add(Me.PictureBox9)
        Me.Controls.Add(Me.PictureBox10)
        Me.Controls.Add(Me.PictureBox11)
        Me.Controls.Add(Me.PictureBox6)
        Me.Controls.Add(Me.PictureBox7)
        Me.Controls.Add(Me.PictureBox8)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.btnTeaCoffee)
        Me.Controls.Add(Me.btnCocktails)
        Me.Controls.Add(Me.btnSpirits)
        Me.Controls.Add(Me.btnSoftDrinks)
        Me.Controls.Add(Me.btnSignOut)
        Me.Controls.Add(Me.btnConfirm)
        Me.Controls.Add(Me.Button13)
        Me.Controls.Add(Me.Button14)
        Me.Controls.Add(Me.Button15)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Button11)
        Me.Controls.Add(Me.Button12)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.btnLager)
        Me.Controls.Add(Me.btnAle)
        Me.Controls.Add(Me.btnCider)
        Me.Controls.Add(Me.btnStout)
        Me.Controls.Add(Me.btnWine)
        Me.Controls.Add(Me.btnWhiskey)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "FrmMain"
        Me.Text = "Menu"
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnWhiskey As System.Windows.Forms.Button
    Friend WithEvents btnWine As System.Windows.Forms.Button
    Friend WithEvents btnStout As System.Windows.Forms.Button
    Friend WithEvents btnCider As System.Windows.Forms.Button
    Friend WithEvents btnAle As System.Windows.Forms.Button
    Friend WithEvents btnLager As System.Windows.Forms.Button
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents btnConfirm As System.Windows.Forms.Button
    Friend WithEvents btnSignOut As System.Windows.Forms.Button
    Friend WithEvents btnSoftDrinks As System.Windows.Forms.Button
    Friend WithEvents btnSpirits As System.Windows.Forms.Button
    Friend WithEvents btnCocktails As System.Windows.Forms.Button
    Friend WithEvents btnTeaCoffee As System.Windows.Forms.Button
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox6 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox7 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox8 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox9 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox10 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox11 As System.Windows.Forms.PictureBox
    Friend WithEvents btnDinner As System.Windows.Forms.Button
    Friend WithEvents btnSoup As System.Windows.Forms.Button
    Friend WithEvents btnLunch As System.Windows.Forms.Button
    Friend WithEvents btnSandwiches As System.Windows.Forms.Button
    Friend WithEvents btnManagerControls As System.Windows.Forms.Button
    Friend WithEvents btnPubSpecials As System.Windows.Forms.Button
    Friend WithEvents btnCrisps As System.Windows.Forms.Button
    Friend WithEvents btnChocolate As System.Windows.Forms.Button
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents Button32 As System.Windows.Forms.Button
    Friend WithEvents Button34 As System.Windows.Forms.Button
    Friend WithEvents Button35 As System.Windows.Forms.Button
    Friend WithEvents Button36 As System.Windows.Forms.Button
    Friend WithEvents Button37 As System.Windows.Forms.Button
End Class
