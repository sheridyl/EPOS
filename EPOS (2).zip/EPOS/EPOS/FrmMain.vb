﻿Public Class FrmMain

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnWhiskey.Click

    End Sub

    Private Sub Button37_Click(sender As Object, e As EventArgs) Handles Button37.Click

    End Sub
End Class